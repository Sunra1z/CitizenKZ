package com.syrnikter.CitizenKZ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitizenKzApplicationTests {

	@Test
	void contextLoads() {
	}

}
