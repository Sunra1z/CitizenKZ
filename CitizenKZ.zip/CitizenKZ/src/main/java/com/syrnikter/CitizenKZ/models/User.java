package com.syrnikter.CitizenKZ.models;

public class User {
}
